package com.hojeonde.hoje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HojeondeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HojeondeApplication.class, args);
	}

}
