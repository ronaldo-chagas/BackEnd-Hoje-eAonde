package com.hojeonde.hoje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HojeondeApplicationTests {

	@Test
	void contextLoads() {
	}

}
